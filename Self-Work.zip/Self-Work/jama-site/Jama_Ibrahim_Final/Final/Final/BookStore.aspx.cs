﻿using System;
using System.Collections;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BookStore : System.Web.UI.Page
{
    private Book _book;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //begin with empty shopping cart
            ShoppingCart cart = ShoppingCart.RetrieveShoppingCart();
            cart.EmptyShoppingCart();

            // receives all books from book catalog.
            ArrayList books = BookCatalogDataAccess.GetAllBooks();
            PopulateDropdown(books);
        }
    }

    protected void PopulateDropdown(ArrayList books)
    {
        // Add default item to drop down list
        var defaultItem = new ListItem
        {
            Selected = true,
            Value = "-1",
            Text = "Select a Book..."
        };

        bookSelection.Items.Add(defaultItem);

        // performs through each customer and populate the dropdown list
        foreach (var listItem in from Book book in BookCatalogDataAccess.GetAllBooks()
                                 select new ListItem
                                 {
                                     Value = book.Id,
                                     Text = book.Title
                                 })
        {
            // Add the list item to the dropdown list
            bookSelection.Items.Add(listItem);
        }
    }

    protected void bookSelection_SelectedIndexChanged(object sender, EventArgs e)
    {
        // Get the selected book object
        _book = BookCatalogDataAccess.GetBookById(bookSelection.SelectedValue);

        // Output the book description and price
        dsr.InnerText = _book.Description;
        bookPrice.Text = Convert.ToString("$" + _book.Price, CultureInfo.InvariantCulture);
    }
    protected void addButton_Click(object sender, EventArgs e)
    {
        dsr.InnerText = "";

        var book = BookCatalogDataAccess.GetBookById(bookSelection.SelectedValue);

        // Add the book to an order
        BookOrder order = new BookOrder(book, Convert.ToInt32(txtQuantity.Text));

        // Add the order to the cart
        ShoppingCart cart = ShoppingCart.RetrieveShoppingCart();
        cart.AddBookOrder(order);

        var itemText = " item";
        var copyText = " copy";

        if (cart.NumOfItems > 1)
        {
            itemText = " items";
            copyText = " copies";
        }

        //
        dsr.InnerText = txtQuantity.Text + copyText + "  of " + book.Title + " is added to the shopping cart";

        // update item count
        viewButton.Text = "View Cart (" + cart.NumOfItems + itemText + ")";

        // updating the drop down
        bookSelection.Items.RemoveAt(bookSelection.SelectedIndex);
        bookSelection.SelectedValue = "-1";
    }
    protected void viewButton_Click(object sender, EventArgs e)
    {
        pnlBookSelectionView.Visible = false;
        pnlShoppingCartView.Visible = true;

        
        var tHead = new TableHeaderRow();
        shoppingCart.Rows.Add(tHead);

        var tHeadCellTitle = new TableHeaderCell();
        var tHeadCellQuantity = new TableHeaderCell();
        var tHeadCellSubtotal = new TableHeaderCell();

        tHeadCellTitle.Text = "Title";
        tHeadCellQuantity.Text = "Quantity";
        tHeadCellSubtotal.Text = "Subtotal";

        tHead.Cells.Add(tHeadCellTitle);
        tHead.Cells.Add(tHeadCellQuantity);
        tHead.Cells.Add(tHeadCellSubtotal);
        
        ShoppingCart cart = ShoppingCart.RetrieveShoppingCart();

        if (cart.IsEmpty)
        {
            var tRow = new TableRow();
            shoppingCart.Rows.Add(tRow);

            var tCell = new TableCell();

            tCell.ColumnSpan = 3;
            tCell.HorizontalAlign = HorizontalAlign.Center;
            tCell.Text = "<span class='error'>Your shopping Cart is Empty</span>";
            tRow.Cells.Add(tCell);
        }

        // table loop
        foreach (BookOrder order in cart.BookOrders)
        {
            // create table row
            var tRow = new TableRow();
            shoppingCart.Rows.Add(tRow);

            // Now the table cells
            var tCellTitle = new TableCell();
            var tCellQuantity = new TableCell();
            var tCellSubtotal = new TableCell();

            tCellTitle.Text = order.Book.Title;
            tCellQuantity.Text = Convert.ToString(order.NumOfCopies);
            tCellSubtotal.Text = Convert.ToString(String.Format("{0:C0}", order.Book.Price * order.NumOfCopies));

            tRow.Cells.Add(tCellTitle);
            tRow.Cells.Add(tCellQuantity);
            tRow.Cells.Add(tCellSubtotal);
        }

        if (!cart.IsEmpty)
        {
            // Generate the table footer
            var tFoot = new TableRow();
            shoppingCart.Rows.Add(tFoot);

            var tFootTotalLabel = new TableCell();
            var tFootTotal = new TableCell();

            tFootTotalLabel.Text = "Total";
            tFootTotalLabel.HorizontalAlign = HorizontalAlign.Right;
            tFootTotalLabel.ColumnSpan = 2;
            tFootTotal.Text = Convert.ToString("$" + cart.TotalAmountPayable);

            tFoot.Cells.Add(tFootTotalLabel);
            tFoot.Cells.Add(tFootTotal);
        }
    }
}